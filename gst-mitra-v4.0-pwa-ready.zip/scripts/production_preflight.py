import os, sys

required = ["SECRET_KEY", "APP_ENV", "CORS_ORIGINS"]
missing = [k for k in required if not os.getenv(k)]
if missing:
    print("FAIL: missing production variables:", ", ".join(missing)); sys.exit(1)
if os.getenv("APP_ENV", "").lower() not in {"production", "staging"}:
    print("FAIL: APP_ENV must be staging or production"); sys.exit(1)
if len(os.getenv("SECRET_KEY", "")) < 32:
    print("FAIL: SECRET_KEY must be at least 32 characters"); sys.exit(1)
if os.getenv("REQUIRE_HTTPS", "true").lower() not in {"1","true","yes","on"}:
    print("FAIL: REQUIRE_HTTPS must be enabled"); sys.exit(1)
if os.getenv("COOKIE_SECURE", "true").lower() not in {"1","true","yes","on"}:
    print("FAIL: COOKIE_SECURE must be enabled"); sys.exit(1)
origins=[x.strip() for x in os.getenv("CORS_ORIGINS","").split(",") if x.strip()]
if any(not x.startswith("https://") for x in origins):
    print("FAIL: all CORS origins must use HTTPS"); sys.exit(1)
print("PASS: production security preflight")
