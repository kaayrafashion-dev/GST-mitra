# GST Mitra HTTPS: localhost → production

## Local
Use a trusted local certificate (for example, mkcert) or the included Caddy reverse proxy.

- UI: https://localhost:5173
- API: https://api.localhost:8000 (or proxy it through Caddy)
- `REQUIRE_HTTPS=true`
- `COOKIE_SECURE=true`

Do not put a private certificate/key in the repository.

## Staging / Production
Set:
- `APP_ENV=staging` or `production`
- `REQUIRE_HTTPS=true`
- `COOKIE_SECURE=true`
- a strong random `SECRET_KEY` (32+ characters; preferably 64+)
- `CORS_ORIGINS` to HTTPS origins only

Terminate TLS at a trusted reverse proxy/load balancer and forward only to the internal API. The application still rejects requests that are not marked HTTPS when `REQUIRE_HTTPS=true`.

## Browser session security
Browser login uses:
- `gstmitra_session`: Secure + HttpOnly + SameSite=Lax
- `gstmitra_csrf`: Secure + SameSite=Lax and sent in `X-CSRF-Token`

The frontend does not store JWTs in localStorage.
