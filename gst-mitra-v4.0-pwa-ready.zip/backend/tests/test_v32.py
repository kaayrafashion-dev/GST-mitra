from fastapi.testclient import TestClient
from app.main import app
import uuid

def test_v32_billing_inventory_pdf():
    c=TestClient(app)
    seed=uuid.uuid4().hex[:8]
    r=c.post('/api/auth/register',json={'business_name':'V32 '+seed,'gstin':f"29ABCDE{int(seed[:4],16)%10000:04d}F1Z5",'email':f'{seed}@example.com','password':'StrongPass123!'})
    assert r.status_code==200
    h={'Authorization':'Bearer '+r.json()['access_token']}
    item=c.post('/api/masters/items',headers=h,json={'name':'Widget','hsn_sac':'1234','gst_rate':18,'unit':'NOS','sale_price':100,'purchase_price':70,'stock_qty':0}).json()
    iid=item['id']
    p=c.post('/api/purchases',headers=h,json={'vendor_name':'Vendor','item_id':iid,'quantity':10,'unit_price':70,'rate':18,'intra_state':True,'eligible_itc':126,'itc_status':'eligible','return_period':'2026-08'})
    assert p.status_code==200
    payload={'customer_name':'Customer','customer_gstin':f"29ABCDE{int(seed[:4],16)%10000:04d}F1Z5",'invoice_date':'2026-08-23','intra_state':True,'return_period':'2026-08','lines':[{'item_id':iid,'description':'Widget','quantity':2,'unit':'NOS','unit_price':100,'rate':18}]}
    assert c.post('/api/invoices/validate',headers=h,json=payload).json()['valid']
    inv=c.post('/api/invoices/multi',headers=h,json=payload)
    assert inv.status_code==200
    pdf=c.get(f"/api/invoices/{inv.json()['id']}/pdf",headers=h)
    assert pdf.status_code==200 and pdf.content.startswith(b'%PDF')
    assert c.get('/api/inventory/stock',headers=h).json()['items'][0]['stock_qty']==8
