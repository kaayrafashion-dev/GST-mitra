import os
import uuid
os.environ.setdefault("REQUIRE_HTTPS","false")
os.environ.setdefault("COOKIE_SECURE","false")
from fastapi.testclient import TestClient
from app.main import app
from app.db import create_business_user
from app.security import create_token

def test_voice_high_impact_is_blocked():
    user=create_business_user("Voice Test Co", "24AABCU9603R1ZA", f"voice-test-v37-{uuid.uuid4().hex[:8]}@example.com", "strong-password-123")
    token=create_token(user["id"], user["business_id"], user["role"])
    c=TestClient(app)
    r=c.post("/api/agent",json={"text":"create invoice for 50000"},headers={"Authorization":f"Bearer {token}"})
    assert r.status_code==200
    d=r.json()
    assert d["intent"]["requires_confirmation"] is True
    assert d["intent"]["action_allowed"] is False

def test_voice_read_only_intent():
    user=create_business_user("Voice Test Co 2", "24AABCU9603R1ZB", f"voice-test2-v37-{uuid.uuid4().hex[:8]}@example.com", "strong-password-123")
    token=create_token(user["id"], user["business_id"], user["role"])
    c=TestClient(app)
    r=c.post("/api/agent",json={"text":"show my GSTR-2B"},headers={"Authorization":f"Bearer {token}"})
    assert r.status_code==200
    assert r.json()["intent"]["intent"]=="itc"
