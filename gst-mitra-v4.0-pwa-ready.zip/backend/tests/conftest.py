import os, tempfile
os.environ.setdefault('GST_MITRA_DB', os.path.join(tempfile.gettempdir(), 'gst_mitra_v33_redteam.sqlite3'))
os.environ['REQUIRE_HTTPS']='false'
os.environ['COOKIE_SECURE']='false'
