import os
os.environ['REQUIRE_HTTPS']='false'
os.environ['COOKIE_SECURE']='false'
from fastapi.testclient import TestClient
from app.main import app
import uuid

def test_cookie_session_and_csrf():
    c=TestClient(app)
    seed=uuid.uuid4().hex[:8]
    r=c.post('/api/auth/register',json={'business_name':'RT '+seed,'gstin':f"29ABCDE{int(seed[:4],16)%10000:04d}F1Z5",'email':f'{seed}@example.com','password':'StrongPass123!'})
    assert r.status_code==200
    assert 'gstmitra_session=' in r.headers.get('set-cookie','')
    assert 'HttpOnly' in r.headers['set-cookie']
    assert 'SameSite=lax' in r.headers['set-cookie']
    # Cookie-authenticated write without CSRF must fail.
    bad=c.post('/api/agent',json={'text':'hello'})
    assert bad.status_code==403
    csrf=c.cookies.get('gstmitra_csrf')
    good=c.post('/api/agent',headers={'X-CSRF-Token':csrf},json={'text':'hello'})
    assert good.status_code==200

def test_logout_clears_session():
    c=TestClient(app)
    seed=uuid.uuid4().hex[:8]
    c.post('/api/auth/register',json={'business_name':'RT '+seed,'gstin':f"29ABCDE{int(seed[:4],16)%10000:04d}F1Z5",'email':f'{seed}@example.com','password':'StrongPass123!'})
    csrf=c.cookies.get('gstmitra_csrf')
    r=c.post('/api/auth/logout',headers={'X-CSRF-Token':csrf})
    assert r.status_code==200
    assert c.get('/api/me').status_code==401

def test_https_redirect_when_enabled():
    # This is a structural/configuration check; production uses REQUIRE_HTTPS=true.
    assert os.getenv('REQUIRE_HTTPS') == 'false'
