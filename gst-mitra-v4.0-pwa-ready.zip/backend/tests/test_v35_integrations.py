import os, uuid
os.environ['REQUIRE_HTTPS']='false'
os.environ['COOKIE_SECURE']='false'
from fastapi.testclient import TestClient
from app.main import app

def reg(c):
    s=uuid.uuid4().hex[:8]
    gst=f"29ABCDE{int(s[:4],16)%10000:04d}F1Z5"
    r=c.post('/api/auth/register',json={'business_name':'V35 '+s,'gstin':gst,'email':f'{s}@example.com','password':'StrongPass123!'})
    assert r.status_code==200
    return c.cookies.get('gstmitra_csrf')

def test_einvoice_and_eway_are_preparation_only():
    c=TestClient(app); csrf=reg(c); h={'X-CSRF-Token':csrf}
    r=c.post('/api/invoices',headers=h,json={'customer_name':'Buyer Pvt Ltd','customer_gstin':'27ABCDE1234F1Z5','subtotal':10000,'rate':18,'intra_state':False,'return_period':'2026-08'})
    assert r.status_code==200, r.text
    inv=r.json()
    r=c.post('/api/integration/e-invoice/prepare',headers=h,json={'invoice_id':inv['invoice_id'],'doc_type':'INV','doc_number':inv['invoice_no'],'recipient_gstin':'27ABCDE1234F1Z5','place_of_supply':'27','supply_type':'B2B'})
    assert r.status_code==200 and r.json()['status']=='draft'
    assert r.json()['irn'] is None
    r=c.post('/api/integration/eway-bill/prepare',headers=h,json={'invoice_id':inv['invoice_id'],'transport_mode':'1','vehicle_number':'GJ01AB1234','vehicle_type':'R','distance_km':120})
    assert r.status_code==200 and r.json()['status']=='draft'
    assert r.json()['eway_bill_no'] is None

def test_einvoice_b2b_requires_gstin():
    c=TestClient(app); csrf=reg(c); h={'X-CSRF-Token':csrf}
    r=c.post('/api/invoices',headers=h,json={'customer_name':'No GSTIN','subtotal':1000,'rate':18,'intra_state':True,'return_period':'2026-08'})
    inv=r.json()
    r=c.post('/api/integration/e-invoice/prepare',headers=h,json={'invoice_id':inv['invoice_id'],'doc_type':'INV','doc_number':inv['invoice_no'],'place_of_supply':'24','supply_type':'B2B'})
    assert r.status_code==422
