from decimal import Decimal, ROUND_HALF_UP

TWOPLACES = Decimal('0.01')

def money(value) -> Decimal:
    return Decimal(str(value)).quantize(TWOPLACES, rounding=ROUND_HALF_UP)

def calculate(subtotal, rate, intra_state: bool = True):
    taxable = money(subtotal)
    gst_rate = money(rate)
    tax = (taxable * gst_rate / Decimal('100')).quantize(TWOPLACES, rounding=ROUND_HALF_UP)
    if intra_state:
        cgst = (tax / 2).quantize(TWOPLACES, rounding=ROUND_HALF_UP)
        sgst = tax - cgst
        igst = Decimal('0.00')
    else:
        cgst = Decimal('0.00'); sgst = Decimal('0.00'); igst = tax
    total = taxable + tax
    return {
        'taxable_value': float(taxable), 'rate': float(gst_rate), 'intra_state': intra_state,
        'cgst': float(cgst), 'sgst': float(sgst), 'igst': float(igst), 'total': float(total)
    }
