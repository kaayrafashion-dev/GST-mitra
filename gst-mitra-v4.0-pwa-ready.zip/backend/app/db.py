import sqlite3, os, uuid
from datetime import datetime, timezone
DB=os.getenv('GST_MITRA_DB','gst_mitra.db')

def conn():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; c.execute('PRAGMA foreign_keys=ON'); return c

def now(): return datetime.now(timezone.utc).isoformat()

def init_db():
    c=conn()
    c.executescript('''
    CREATE TABLE IF NOT EXISTS businesses(id TEXT PRIMARY KEY,name TEXT NOT NULL,gstin TEXT NOT NULL UNIQUE,created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,business_id TEXT NOT NULL,email TEXT NOT NULL UNIQUE,password_hash TEXT NOT NULL,role TEXT NOT NULL DEFAULT 'owner',created_at TEXT NOT NULL,FOREIGN KEY(business_id) REFERENCES businesses(id));
    CREATE TABLE IF NOT EXISTS invoices(id TEXT PRIMARY KEY,business_id TEXT NOT NULL,invoice_no TEXT,customer_name TEXT NOT NULL,customer_gstin TEXT,description TEXT NOT NULL DEFAULT 'Taxable supply',hsn_sac TEXT NOT NULL DEFAULT '',invoice_date TEXT,subtotal REAL NOT NULL,rate REAL NOT NULL,intra_state INTEGER NOT NULL,cgst REAL NOT NULL,sgst REAL NOT NULL,igst REAL NOT NULL,total REAL NOT NULL,return_period TEXT NOT NULL,created_at TEXT NOT NULL,FOREIGN KEY(business_id) REFERENCES businesses(id));
    CREATE TABLE IF NOT EXISTS purchases(id TEXT PRIMARY KEY,business_id TEXT NOT NULL,vendor_name TEXT NOT NULL,vendor_gstin TEXT,taxable_value REAL NOT NULL,rate REAL NOT NULL,eligible_itc REAL NOT NULL,cgst REAL NOT NULL,sgst REAL NOT NULL,igst REAL NOT NULL,itc_status TEXT NOT NULL DEFAULT 'pending',return_period TEXT NOT NULL,created_at TEXT NOT NULL,FOREIGN KEY(business_id) REFERENCES businesses(id));
    CREATE TABLE IF NOT EXISTS accounting_periods(business_id TEXT NOT NULL,period TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'open',locked_by TEXT,locked_at TEXT,PRIMARY KEY(business_id,period),FOREIGN KEY(business_id) REFERENCES businesses(id));
    CREATE TABLE IF NOT EXISTS audit_logs(id TEXT PRIMARY KEY,business_id TEXT NOT NULL,user_id TEXT NOT NULL,action TEXT NOT NULL,object_type TEXT,object_id TEXT,metadata TEXT,created_at TEXT NOT NULL,FOREIGN KEY(business_id) REFERENCES businesses(id));
    CREATE TABLE IF NOT EXISTS parties(id TEXT PRIMARY KEY,business_id TEXT NOT NULL,name TEXT NOT NULL,gstin TEXT,party_type TEXT NOT NULL CHECK(party_type IN ('customer','vendor','both')),phone TEXT,email TEXT,address TEXT,created_at TEXT NOT NULL,FOREIGN KEY(business_id) REFERENCES businesses(id));
    CREATE TABLE IF NOT EXISTS items(id TEXT PRIMARY KEY,business_id TEXT NOT NULL,name TEXT NOT NULL,hsn_sac TEXT,gst_rate REAL NOT NULL DEFAULT 0,unit TEXT NOT NULL DEFAULT 'NOS',sale_price REAL NOT NULL DEFAULT 0,purchase_price REAL NOT NULL DEFAULT 0,stock_qty REAL NOT NULL DEFAULT 0,created_at TEXT NOT NULL,FOREIGN KEY(business_id) REFERENCES businesses(id));
    CREATE TABLE IF NOT EXISTS invoice_sequences(business_id TEXT NOT NULL,return_period TEXT NOT NULL,last_number INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(business_id,return_period),FOREIGN KEY(business_id) REFERENCES businesses(id));
    CREATE TABLE IF NOT EXISTS stock_movements(id TEXT PRIMARY KEY,business_id TEXT NOT NULL,item_id TEXT NOT NULL,invoice_id TEXT,move_type TEXT NOT NULL CHECK(move_type IN ('sale','purchase','adjustment')),qty REAL NOT NULL,created_at TEXT NOT NULL,FOREIGN KEY(business_id) REFERENCES businesses(id),FOREIGN KEY(item_id) REFERENCES items(id));
    CREATE TABLE IF NOT EXISTS invoice_lines(id TEXT PRIMARY KEY,invoice_id TEXT NOT NULL,business_id TEXT NOT NULL,item_id TEXT,description TEXT NOT NULL,hsn_sac TEXT,quantity REAL NOT NULL,unit TEXT NOT NULL DEFAULT 'NOS',unit_price REAL NOT NULL,taxable_value REAL NOT NULL,gst_rate REAL NOT NULL,cgst REAL NOT NULL,sgst REAL NOT NULL,igst REAL NOT NULL,total REAL NOT NULL,FOREIGN KEY(invoice_id) REFERENCES invoices(id),FOREIGN KEY(business_id) REFERENCES businesses(id));
    CREATE TABLE IF NOT EXISTS purchase_lines(id TEXT PRIMARY KEY,purchase_id TEXT NOT NULL,business_id TEXT NOT NULL,item_id TEXT,description TEXT NOT NULL,hsn_sac TEXT,quantity REAL NOT NULL,unit TEXT NOT NULL DEFAULT 'NOS',unit_price REAL NOT NULL,taxable_value REAL NOT NULL,gst_rate REAL NOT NULL,eligible_itc REAL NOT NULL,FOREIGN KEY(purchase_id) REFERENCES purchases(id),FOREIGN KEY(business_id) REFERENCES businesses(id));
    CREATE TABLE IF NOT EXISTS credit_debit_notes(id TEXT PRIMARY KEY,business_id TEXT NOT NULL,note_type TEXT NOT NULL CHECK(note_type IN ('credit','debit')),reference_invoice TEXT,party_name TEXT NOT NULL,taxable_value REAL NOT NULL,rate REAL NOT NULL,reason TEXT,return_period TEXT NOT NULL,created_at TEXT NOT NULL,FOREIGN KEY(business_id) REFERENCES businesses(id));
    CREATE TABLE IF NOT EXISTS gstr2b_records(id TEXT PRIMARY KEY,business_id TEXT NOT NULL,return_period TEXT NOT NULL,supplier_gstin TEXT NOT NULL,supplier_name TEXT NOT NULL,invoice_no TEXT NOT NULL,invoice_date TEXT,taxable_value REAL NOT NULL,igst REAL NOT NULL DEFAULT 0,cgst REAL NOT NULL DEFAULT 0,sgst REAL NOT NULL DEFAULT 0,total_tax REAL NOT NULL,source_hash TEXT NOT NULL,match_status TEXT NOT NULL DEFAULT 'unmatched',matched_purchase_id TEXT,created_at TEXT NOT NULL,FOREIGN KEY(business_id) REFERENCES businesses(id));
    CREATE TABLE IF NOT EXISTS e_invoice_preparations(id TEXT PRIMARY KEY,business_id TEXT NOT NULL,invoice_id TEXT NOT NULL,doc_type TEXT NOT NULL,doc_number TEXT NOT NULL,doc_date TEXT,recipient_gstin TEXT,place_of_supply TEXT,supply_type TEXT NOT NULL,transport_mode TEXT,irn TEXT,ack_number TEXT,status TEXT NOT NULL DEFAULT 'draft',payload_hash TEXT NOT NULL,created_at TEXT NOT NULL,FOREIGN KEY(business_id) REFERENCES businesses(id),FOREIGN KEY(invoice_id) REFERENCES invoices(id));
    CREATE UNIQUE INDEX IF NOT EXISTS uq_einvoice_business_invoice ON e_invoice_preparations(business_id,invoice_id);
    CREATE TABLE IF NOT EXISTS eway_bill_preparations(id TEXT PRIMARY KEY,business_id TEXT NOT NULL,invoice_id TEXT NOT NULL,doc_number TEXT NOT NULL,doc_date TEXT,from_gstin TEXT NOT NULL,to_gstin TEXT,transport_mode TEXT NOT NULL,transporter_id TEXT,vehicle_number TEXT,vehicle_type TEXT,distance_km REAL NOT NULL,irn TEXT,eway_bill_no TEXT,status TEXT NOT NULL DEFAULT 'draft',payload_hash TEXT NOT NULL,created_at TEXT NOT NULL,FOREIGN KEY(business_id) REFERENCES businesses(id),FOREIGN KEY(invoice_id) REFERENCES invoices(id));
    CREATE UNIQUE INDEX IF NOT EXISTS uq_eway_business_invoice ON eway_bill_preparations(business_id,invoice_id);
    CREATE INDEX IF NOT EXISTS idx_gstr2b_business_period ON gstr2b_records(business_id,return_period,match_status);
    CREATE INDEX IF NOT EXISTS idx_invoices_business_period_created ON invoices(business_id,return_period,created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_purchases_business_period_created ON purchases(business_id,return_period,created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_audit_business_created ON audit_logs(business_id,created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_parties_business_name ON parties(business_id,name);
    CREATE INDEX IF NOT EXISTS idx_items_business_name ON items(business_id,name);
    CREATE INDEX IF NOT EXISTS idx_invoice_lines_invoice ON invoice_lines(business_id,invoice_id);
    CREATE INDEX IF NOT EXISTS idx_purchase_lines_purchase ON purchase_lines(business_id,purchase_id);
    CREATE INDEX IF NOT EXISTS idx_stock_movements_item ON stock_movements(business_id,item_id,created_at DESC);
    ''')
    # Lightweight migration for V2 databases created before tenant isolation.
    for table in ('invoices','purchases'):
        cols={r['name'] for r in c.execute(f'PRAGMA table_info({table})')}
        if 'business_id' not in cols: c.execute(f"ALTER TABLE {table} ADD COLUMN business_id TEXT")
        if table=='invoices' and 'return_period' not in cols: c.execute(f"ALTER TABLE {table} ADD COLUMN return_period TEXT DEFAULT ''")
        if table=='purchases':
            if 'itc_status' not in cols: c.execute(f"ALTER TABLE {table} ADD COLUMN itc_status TEXT DEFAULT 'pending'")
            if 'return_period' not in cols: c.execute(f"ALTER TABLE {table} ADD COLUMN return_period TEXT DEFAULT ''")

    invoice_cols={r['name'] for r in c.execute('PRAGMA table_info(invoices)')}
    for col,ddl in [('description',"TEXT NOT NULL DEFAULT 'Taxable supply'"),('hsn_sac',"TEXT NOT NULL DEFAULT ''"),('invoice_date','TEXT')]:
        if col not in invoice_cols: c.execute(f'ALTER TABLE invoices ADD COLUMN {col} {ddl}')
    if 'invoice_no' not in invoice_cols: c.execute("ALTER TABLE invoices ADD COLUMN invoice_no TEXT")
    item_cols={r['name'] for r in c.execute('PRAGMA table_info(items)')}
    if item_cols and 'stock_qty' not in item_cols: c.execute("ALTER TABLE items ADD COLUMN stock_qty REAL NOT NULL DEFAULT 0")
    c.commit(); c.close()

def create_business_user(name,gstin,email,password_hash):
    c=conn(); bid=str(uuid.uuid4()); uid=str(uuid.uuid4())
    try:
        c.execute('INSERT INTO businesses VALUES (?,?,?,?)',(bid,name,gstin,now()))
        c.execute('INSERT INTO users(id,business_id,email,password_hash,role,created_at) VALUES (?,?,?,?,?,?)',(uid,bid,email,password_hash,'owner',now()))
        c.commit(); return {'id':uid,'business_id':bid,'role':'owner','email':email}
    except sqlite3.IntegrityError as e:
        c.rollback(); raise ValueError('Email or GSTIN already registered') from e
    finally: c.close()

def get_user_by_email(email):
    c=conn(); r=c.execute('SELECT * FROM users WHERE lower(email)=lower(?)',(email,)).fetchone(); c.close(); return dict(r) if r else None

def audit(business_id,user_id,action,object_type=None,object_id=None,metadata=''):
    c=conn(); c.execute('INSERT INTO audit_logs VALUES (?,?,?,?,?,?,?,?)',(str(uuid.uuid4()),business_id,user_id,action,object_type,object_id,metadata,now())); c.commit(); c.close()

def next_invoice_no(business_id, period):
    c=conn()
    row=c.execute('SELECT last_number FROM invoice_sequences WHERE business_id=? AND return_period=?',(business_id,period)).fetchone()
    n=(row['last_number'] if row else 0)+1
    if row: c.execute('UPDATE invoice_sequences SET last_number=? WHERE business_id=? AND return_period=?',(n,business_id,period))
    else: c.execute('INSERT INTO invoice_sequences(business_id,return_period,last_number) VALUES (?,?,?)',(business_id,period,n))
    c.commit(); c.close(); return f'{period.replace("-","")}-{n:05d}'

def save_invoice(data,user):
    c=conn(); c.execute('INSERT INTO invoices(id,business_id,invoice_no,customer_name,customer_gstin,description,hsn_sac,invoice_date,subtotal,rate,intra_state,cgst,sgst,igst,total,return_period,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(
      data['invoice_id'],user['business_id'],data.get('invoice_no'),data['customer_name'],data.get('customer_gstin',''),data.get('description','Taxable supply'),data.get('hsn_sac',''),data.get('invoice_date'),data['taxable_value'],data['rate'],int(data['intra_state']),data['cgst'],data['sgst'],data['igst'],data['total'],data['return_period'],now())); c.commit(); c.close(); audit(user['business_id'],user['sub'],'invoice.create','invoice',data['invoice_id'])
    return data

def recent_invoices(user,limit=20,period=None):
    c=conn(); q='SELECT * FROM invoices WHERE business_id=?'; p=[user['business_id']]
    if period: q+=' AND return_period=?'; p.append(period)
    q+=' ORDER BY created_at DESC LIMIT ?'; p.append(limit)
    rows=[dict(r) for r in c.execute(q,p)]; c.close(); return rows

def save_purchase(data,user):
    c=conn(); c.execute('INSERT INTO purchases(id,business_id,vendor_name,vendor_gstin,taxable_value,rate,eligible_itc,cgst,sgst,igst,itc_status,return_period,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)',(
      data['purchase_id'],user['business_id'],data['vendor_name'],data.get('vendor_gstin',''),data['taxable_value'],data['rate'],data['eligible_itc'],data['cgst'],data['sgst'],data['igst'],data['itc_status'],data['return_period'],now())); c.commit(); c.close(); audit(user['business_id'],user['sub'],'purchase.create','purchase',data['purchase_id'])

def recent_purchases(user,limit=50,period=None):
    c=conn(); q='SELECT * FROM purchases WHERE business_id=?'; p=[user['business_id']]
    if period: q+=' AND return_period=?'; p.append(period)
    q+=' ORDER BY created_at DESC LIMIT ?'; p.append(limit)
    rows=[dict(r) for r in c.execute(q,p)]; c.close(); return rows


def record_stock_sale(item_id, invoice_id, qty, user):
    if qty <= 0: return
    c=conn(); row=c.execute('SELECT stock_qty FROM items WHERE id=? AND business_id=?',(item_id,user['business_id'])).fetchone()
    if not row: c.close(); raise ValueError('Item not found')
    if row['stock_qty'] < qty: c.close(); raise ValueError('Insufficient stock')
    c.execute('UPDATE items SET stock_qty=stock_qty-? WHERE id=? AND business_id=?',(qty,item_id,user['business_id']))
    c.execute('INSERT INTO stock_movements VALUES (?,?,?,?,?,?,?)',(str(uuid.uuid4()),user['business_id'],item_id,invoice_id,'sale',qty,now())); c.commit(); c.close(); audit(user['business_id'],user['sub'],'stock.sale','item',item_id, f'qty={qty}')

def list_stock(user):
    c=conn(); rows=[dict(r) for r in c.execute('SELECT id,name,hsn_sac,unit,gst_rate,sale_price,purchase_price,stock_qty FROM items WHERE business_id=? ORDER BY name',(user['business_id'],))]; c.close(); return rows

def create_party(data,user):
    c=conn(); pid=str(uuid.uuid4())
    try:
        c.execute('INSERT INTO parties VALUES (?,?,?,?,?,?,?,?,?)',(pid,user['business_id'],data['name'],data.get('gstin',''),data['party_type'],data.get('phone',''),data.get('email',''),data.get('address',''),now())); c.commit()
    finally: c.close()
    audit(user['business_id'],user['sub'],'party.create','party',pid)
    return {'id':pid,**data}

def list_parties(user,party_type=None):
    c=conn(); q='SELECT * FROM parties WHERE business_id=?'; p=[user['business_id']]
    if party_type: q+=' AND party_type=?'; p.append(party_type)
    q+=' ORDER BY name'; rows=[dict(r) for r in c.execute(q,p)]; c.close(); return rows

def create_item(data,user):
    c=conn(); iid=str(uuid.uuid4())
    c.execute('INSERT INTO items VALUES (?,?,?,?,?,?,?,?,?,?)',(iid,user['business_id'],data['name'],data.get('hsn_sac',''),data.get('gst_rate',0),data.get('unit','NOS'),data.get('sale_price',0),data.get('purchase_price',0),data.get('stock_qty',0),now())); c.commit(); c.close()
    audit(user['business_id'],user['sub'],'item.create','item',iid)
    return {'id':iid,**data}

def list_items(user):
    c=conn(); rows=[dict(r) for r in c.execute('SELECT * FROM items WHERE business_id=? ORDER BY name',(user['business_id'],))]; c.close(); return rows

def create_note(data,user):
    c=conn(); nid=str(uuid.uuid4())
    c.execute('INSERT INTO credit_debit_notes VALUES (?,?,?,?,?,?,?,?,?,?)',(nid,user['business_id'],data['note_type'],data.get('reference_invoice',''),data['party_name'],data['taxable_value'],data['rate'],data.get('reason',''),data['return_period'],now())); c.commit(); c.close()
    audit(user['business_id'],user['sub'],f"{data['note_type']}_note.create",'note',nid)
    return {'id':nid,**data}

def list_notes(user,period=None):
    c=conn(); q='SELECT * FROM credit_debit_notes WHERE business_id=?'; p=[user['business_id']]
    if period: q+=' AND return_period=?'; p.append(period)
    q+=' ORDER BY created_at DESC'; rows=[dict(r) for r in c.execute(q,p)]; c.close(); return rows


def get_invoice(user, invoice_id):
    c=conn(); inv=c.execute('SELECT * FROM invoices WHERE id=? AND business_id=?',(invoice_id,user['business_id'])).fetchone()
    if not inv: c.close(); return None
    lines=[dict(r) for r in c.execute('SELECT * FROM invoice_lines WHERE invoice_id=? AND business_id=? ORDER BY rowid',(invoice_id,user['business_id']))]
    c.close(); d=dict(inv); d['lines']=lines; return d

def add_invoice_line(data,user):
    c=conn(); c.execute('INSERT INTO invoice_lines VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(str(uuid.uuid4()),data['invoice_id'],user['business_id'],data.get('item_id'),data['description'],data.get('hsn_sac',''),data['quantity'],data.get('unit','NOS'),data['unit_price'],data['taxable_value'],data['rate'],data['cgst'],data['sgst'],data['igst'],data['total'])); c.commit(); c.close()

def save_purchase_line(data,user):
    c=conn(); c.execute('INSERT INTO purchase_lines VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',(str(uuid.uuid4()),data['purchase_id'],user['business_id'],data.get('item_id'),data['description'],data.get('hsn_sac',''),data['quantity'],data.get('unit','NOS'),data['unit_price'],data['taxable_value'],data['rate'],data['eligible_itc'])); c.commit(); c.close()

def record_stock_purchase(item_id,purchase_id,qty,user):
    if qty <= 0: raise ValueError('Quantity must be positive')
    c=conn(); row=c.execute('SELECT id FROM items WHERE id=? AND business_id=?',(item_id,user['business_id'])).fetchone()
    if not row: c.close(); raise ValueError('Item not found')
    c.execute('UPDATE items SET stock_qty=stock_qty+? WHERE id=? AND business_id=?',(qty,item_id,user['business_id']))
    c.execute('INSERT INTO stock_movements VALUES (?,?,?,?,?,?,?)',(str(uuid.uuid4()),user['business_id'],item_id,purchase_id,'purchase',qty,now())); c.commit(); c.close(); audit(user['business_id'],user['sub'],'stock.purchase','item',item_id,f'qty={qty}')

def adjust_stock(item_id, qty, reason, user):
    c=conn(); row=c.execute('SELECT stock_qty FROM items WHERE id=? AND business_id=?',(item_id,user['business_id'])).fetchone()
    if not row: c.close(); raise ValueError('Item not found')
    new_qty=row['stock_qty']+qty
    if new_qty < 0: c.close(); raise ValueError('Adjustment would make stock negative')
    c.execute('UPDATE items SET stock_qty=? WHERE id=? AND business_id=?',(new_qty,item_id,user['business_id']))
    c.execute('INSERT INTO stock_movements VALUES (?,?,?,?,?,?,?)',(str(uuid.uuid4()),user['business_id'],item_id,None,'adjustment',qty,now())); c.commit(); c.close(); audit(user['business_id'],user['sub'],'stock.adjustment','item',item_id,reason or f'qty={qty}')
    return {'item_id':item_id,'previous_qty':row['stock_qty'],'adjustment':qty,'new_qty':new_qty,'reason':reason}

def stock_movements(user,item_id=None,limit=100):
    c=conn(); q='SELECT * FROM stock_movements WHERE business_id=?'; p=[user['business_id']]
    if item_id: q+=' AND item_id=?'; p.append(item_id)
    q+=' ORDER BY created_at DESC LIMIT ?'; p.append(max(1,min(limit,500)))
    rows=[dict(r) for r in c.execute(q,p)]; c.close(); return rows


def upsert_gstr2b_record(data,user):
    c=conn(); existing=c.execute('SELECT id FROM gstr2b_records WHERE business_id=? AND source_hash=?',(user['business_id'],data['source_hash'])).fetchone()
    if existing:
        c.close(); return {'id':existing['id'],'duplicate':True}
    rid=str(uuid.uuid4())
    c.execute('INSERT INTO gstr2b_records(id,business_id,return_period,supplier_gstin,supplier_name,invoice_no,invoice_date,taxable_value,igst,cgst,sgst,total_tax,source_hash,match_status,matched_purchase_id,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)', (rid,user['business_id'],data['return_period'],data['supplier_gstin'],data['supplier_name'],data['invoice_no'],data.get('invoice_date'),data['taxable_value'],data['igst'],data['cgst'],data['sgst'],data['total_tax'],data['source_hash'],'unmatched',None,now()))
    c.commit(); c.close(); audit(user['business_id'],user['sub'],'gstr2b.import','gstr2b',rid)
    return {'id':rid,'duplicate':False}

def list_gstr2b(user,period,status=None):
    c=conn(); q='SELECT * FROM gstr2b_records WHERE business_id=? AND return_period=?'; p=[user['business_id'],period]
    if status: q+=' AND match_status=?'; p.append(status)
    q+=' ORDER BY supplier_name,invoice_no'; rows=[dict(r) for r in c.execute(q,p)]; c.close(); return rows

def reconcile_gstr2b(user,period):
    c=conn(); rows=c.execute('SELECT * FROM gstr2b_records WHERE business_id=? AND return_period=?',(user['business_id'],period)).fetchall()
    results=[]
    for r in rows:
        candidates=c.execute('SELECT * FROM purchases WHERE business_id=? AND return_period=? AND vendor_gstin=? ORDER BY created_at DESC',(user['business_id'],period,r['supplier_gstin'])).fetchall() if r['supplier_gstin'] else []
        best=None
        for pu in candidates:
            taxable_diff=abs(float(pu['taxable_value'])-float(r['taxable_value']))
            tax_total=float(pu['cgst'])+float(pu['sgst'])+float(pu['igst'])
            tax_diff=abs(tax_total-float(r['total_tax']))
            if taxable_diff <= 0.01 and tax_diff <= 0.01:
                best=pu; break
        if best:
            status='matched'
            c.execute('UPDATE gstr2b_records SET match_status=?,matched_purchase_id=? WHERE id=? AND business_id=?',(status,best['id'],r['id'],user['business_id']))
        else:
            status='mismatch'
            c.execute('UPDATE gstr2b_records SET match_status=?,matched_purchase_id=NULL WHERE id=? AND business_id=?',(status,r['id'],user['business_id']))
        results.append({'gstr2b_id':r['id'],'status':status,'purchase_id':best['id'] if best else None})
    c.commit(); c.close(); audit(user['business_id'],user['sub'],'gstr2b.reconcile','period',period,f'rows={len(rows)}')
    return results


def get_period_status(user, period):
    c=conn(); r=c.execute('SELECT period,status,locked_by,locked_at FROM accounting_periods WHERE business_id=? AND period=?',(user['business_id'],period)).fetchone(); c.close(); return dict(r) if r else {'period':period,'status':'open','locked_by':None,'locked_at':None}

def set_period_status(user, period, status):
    c=conn(); r=c.execute('SELECT period FROM accounting_periods WHERE business_id=? AND period=?',(user['business_id'],period)).fetchone(); ts=now() if status=='locked' else None
    if r: c.execute('UPDATE accounting_periods SET status=?,locked_by=?,locked_at=? WHERE business_id=? AND period=?',(status,user['sub'] if status=='locked' else None,ts,user['business_id'],period))
    else: c.execute('INSERT INTO accounting_periods VALUES (?,?,?,?,?)',(user['business_id'],period,status,user['sub'] if status=='locked' else None,ts))
    c.commit(); c.close(); audit(user['business_id'],user['sub'],f'period.{status}','accounting_period',period); return get_period_status(user,period)
