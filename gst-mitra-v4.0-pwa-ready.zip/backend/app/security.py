import os, re, time, hashlib, hmac, base64, secrets
from collections import defaultdict
from fastapi import HTTPException, Request, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
import jwt
from .config import SECRET_KEY as CONFIG_SECRET_KEY, TOKEN_MINUTES, APP_ENV

if len(CONFIG_SECRET_KEY) < 32:
    if APP_ENV in ('production','staging'):
        raise RuntimeError('SECRET_KEY must be at least 32 characters in staging/production')
    SECRET_KEY='DEV_ONLY_' + hashlib.sha256((CONFIG_SECRET_KEY or 'gst-mitra-local-dev').encode()).hexdigest()
else:
    SECRET_KEY=CONFIG_SECRET_KEY
ALGORITHM='HS256'
_attempts=defaultdict(list)
BLOCKED=re.compile(r'(ignore\s+(all|any|the)\s+previous|system\s+prompt|developer\s+message|jailbreak|exfiltrat|reveal\s+(the\s+)?(api|secret|system)|api\s*key|secret\s*key|credential|password)',re.I)
bearer=HTTPBearer(auto_error=False)
GSTIN_RE=re.compile(r'^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]$')
PERIOD_RE=re.compile(r'^\d{4}-(0[1-9]|1[0-2])$')


def guard_text(text:str):
    if len(text)>2000: raise HTTPException(413,'Input too long')
    if '\x00' in text: raise HTTPException(400,'Invalid input')
    if BLOCKED.search(text): raise HTTPException(400,'Unsafe instruction detected')
    return text

def validate_gstin(gstin:str):
    value=gstin.strip().upper()
    if not GSTIN_RE.fullmatch(value): raise HTTPException(400,'Invalid GSTIN format')
    return value

def validate_period(period:str):
    value=period.strip()
    if not PERIOD_RE.fullmatch(value): raise HTTPException(400,'Return period must be YYYY-MM')
    return value

def rate_limit(key='global', limit=60, window=60):
    now=time.time(); arr=[t for t in _attempts[key] if now-t<window]
    if len(arr)>=limit: raise HTTPException(429,'Too many requests')
    arr.append(now); _attempts[key]=arr
    if len(_attempts)>5000:
        for k in list(_attempts)[:1000]: _attempts.pop(k,None)

def hash_password(password:str)->str:
    if len(password)<10: raise HTTPException(400,'Password must be at least 10 characters')
    salt=os.urandom(16)
    digest=hashlib.scrypt(password.encode(),salt=salt,n=2**14,r=8,p=1)
    return base64.b64encode(salt+digest).decode()

def verify_password(password:str, encoded:str)->bool:
    try:
        raw=base64.b64decode(encoded.encode()); salt,expected=raw[:16],raw[16:]
        actual=hashlib.scrypt(password.encode(),salt=salt,n=2**14,r=8,p=1)
        return hmac.compare_digest(actual,expected)
    except Exception: return False

def create_token(user_id:str,business_id:str,role:str):
    now=int(time.time())
    payload={'sub':user_id,'business_id':business_id,'role':role,'jti':secrets.token_urlsafe(12),'iat':now,'exp':now+TOKEN_MINUTES*60}
    return jwt.encode(payload,SECRET_KEY,algorithm=ALGORITHM)

def decode_token(token:str):
    try:
        payload=jwt.decode(token,SECRET_KEY,algorithms=[ALGORITHM],options={'require':['exp','iat','sub','business_id','role','jti']})
        if not payload.get('sub') or not payload.get('business_id'): raise HTTPException(401,'Invalid authentication token')
        return payload
    except jwt.ExpiredSignatureError: raise HTTPException(401,'Session expired')
    except jwt.InvalidTokenError: raise HTTPException(401,'Invalid authentication token')

def current_user(request: Request, credentials: HTTPAuthorizationCredentials=Depends(bearer)):
    # Cookie sessions are preferred for browsers. Bearer remains for trusted API clients and tests.
    token=request.cookies.get('gstmitra_session')
    if token:
        return decode_token(token)
    if credentials:
        return decode_token(credentials.credentials)
    raise HTTPException(401,'Authentication required')

def require_role(*roles):
    def dep(user=Depends(current_user)):
        if user.get('role') not in roles: raise HTTPException(403,'Insufficient permissions')
        return user
    return dep

def client_key(request:Request, user=None):
    ip=request.client.host if request.client else 'unknown'
    return f"{ip}:{user.get('sub') if user else 'anon'}"
