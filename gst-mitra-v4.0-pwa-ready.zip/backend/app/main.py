from fastapi import FastAPI, Request, Response, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field, EmailStr
from .gst import calculate
from .agent import reply, classify_intent
from .security import guard_text, rate_limit, client_key, current_user, create_token, hash_password, verify_password, validate_gstin, validate_period
from .db import init_db, create_business_user, get_user_by_email, save_invoice, recent_invoices, save_purchase, recent_purchases, audit, conn, create_party, list_parties, create_item, list_items, create_note, list_notes, next_invoice_no, record_stock_sale, record_stock_purchase, add_invoice_line, save_purchase_line, get_invoice, adjust_stock, stock_movements, list_stock, upsert_gstr2b_record, list_gstr2b, reconcile_gstr2b, get_period_status, set_period_status
import uuid, datetime, html, os, secrets, hmac, hashlib, json
from decimal import Decimal
from fastapi.responses import StreamingResponse
from io import BytesIO
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

app=FastAPI(title='GST Mitra API',version='4.0.0')
init_db()
from .config import CORS_ORIGINS, RATE_LIMIT_PER_MINUTE, COOKIE_SECURE, REQUIRE_HTTPS, TOKEN_MINUTES
app.add_middleware(CORSMiddleware,allow_origins=CORS_ORIGINS,allow_credentials=True,allow_methods=['GET','POST','OPTIONS'],allow_headers=['Authorization','Content-Type'])

class Register(BaseModel): business_name:str=Field(min_length=2,max_length=120); gstin:str=Field(min_length=15,max_length=15); email:EmailStr; password:str=Field(min_length=10,max_length=128)
class Login(BaseModel): email:EmailStr; password:str=Field(min_length=1,max_length=128)
class Calc(BaseModel): subtotal: float=Field(ge=0); rate: float=Field(ge=0,le=100); intra_state: bool=True
class AgentReq(BaseModel): text:str=Field(min_length=1,max_length=2000)
class AgentConfirm(BaseModel): action_id:str=Field(min_length=16,max_length=128); confirmed:bool
class Invoice(BaseModel): item_id:str|None=None; quantity:float=Field(default=1,gt=0); customer_name:str=Field(min_length=1,max_length=200); customer_gstin:str=Field(default='',max_length=15); description:str=Field(default='Taxable supply',max_length=250); hsn_sac:str=Field(default='',max_length=20); invoice_date:str|None=None; subtotal:float=Field(ge=0); rate:float=Field(ge=0,le=100); intra_state:bool=True; return_period:str=Field(pattern=r'^\d{4}-(0[1-9]|1[0-2])$')
class Purchase(BaseModel): vendor_name:str=Field(min_length=1,max_length=200); vendor_gstin:str=Field(default='',max_length=15); taxable_value:float=Field(ge=0); rate:float=Field(ge=0,le=100); intra_state:bool=True; eligible_itc:float|None=Field(default=None,ge=0); itc_status:str=Field(default='pending',pattern='^(pending|matched|eligible|blocked|reversal)$'); return_period:str=Field(pattern=r'^\d{4}-(0[1-9]|1[0-2])$')
class PurchaseV2(BaseModel): vendor_name:str=Field(min_length=1,max_length=200); vendor_gstin:str=''; item_id:str|None=None; quantity:float=Field(default=1,gt=0); unit_price:float=Field(default=0,ge=0); taxable_value:float|None=Field(default=None,ge=0); description:str='Purchase'; hsn_sac:str=''; rate:float=Field(ge=0,le=100); intra_state:bool=True; eligible_itc:float|None=Field(default=None,ge=0); itc_status:str=Field(default='pending',pattern='^(pending|matched|eligible|blocked|reversal)$'); return_period:str=Field(pattern=r'^\d{4}-(0[1-9]|1[0-2])$')
class StockAdjustment(BaseModel): item_id:str; quantity:float; reason:str=Field(default='',max_length=250)
class InvoiceLine(BaseModel): item_id:str|None=None; description:str=Field(min_length=1,max_length=250); hsn_sac:str=''; quantity:float=Field(gt=0); unit:str='NOS'; unit_price:float=Field(ge=0); rate:float=Field(ge=0,le=100)
class MultiInvoice(BaseModel): customer_name:str=Field(min_length=1,max_length=200); customer_gstin:str=''; invoice_date:str|None=None; intra_state:bool=True; return_period:str=Field(pattern=r'^\d{4}-(0[1-9]|1[0-2])$'); lines:list[InvoiceLine]=Field(min_length=1,max_length=100)



class GSTR2BRecord(BaseModel):
    return_period:str=Field(pattern=r'^\d{4}-(0[1-9]|1[0-2])$')
    supplier_gstin:str=Field(min_length=15,max_length=15)
    supplier_name:str=Field(min_length=1,max_length=200)
    invoice_no:str=Field(min_length=1,max_length=60)
    invoice_date:str|None=None
    taxable_value:float=Field(ge=0)
    igst:float=Field(default=0,ge=0)
    cgst:float=Field(default=0,ge=0)
    sgst:float=Field(default=0,ge=0)
    total_tax:float=Field(ge=0)

class GSTR2BImport(BaseModel):
    records:list[GSTR2BRecord]=Field(min_length=1,max_length=5000)

class EInvoicePrepare(BaseModel):
    invoice_id:str
    doc_type:str=Field(default='INV',pattern='^(INV|CRN|DBN)$')
    doc_number:str=Field(min_length=1,max_length=60)
    doc_date:str|None=None
    recipient_gstin:str=''; place_of_supply:str=Field(default='',max_length=50)
    supply_type:str=Field(default='B2B',pattern='^(B2B|B2C|EXP|SEZWP|SEZWOP|DEXP)$')
    transport_mode:str|None=Field(default=None,pattern='^(1|2|3|4)$')

class EWayPrepare(BaseModel):
    invoice_id:str
    transport_mode:str=Field(pattern='^(1|2|3|4)$')
    transporter_id:str=''; vehicle_number:str=''; vehicle_type:str=Field(default='R',pattern='^(R|O)$')
    distance_km:float=Field(gt=0,le=5000)


class Party(BaseModel): name:str=Field(min_length=1,max_length=200); gstin:str=''; party_type:str=Field(default='customer',pattern='^(customer|vendor|both)$'); phone:str=''; email:EmailStr|None=None; address:str=''
class Item(BaseModel): name:str=Field(min_length=1,max_length=200); hsn_sac:str=''; gst_rate:float=Field(ge=0,le=100); unit:str='NOS'; sale_price:float=Field(ge=0); purchase_price:float=Field(ge=0); stock_qty:float=Field(default=0,ge=0)
class Note(BaseModel): note_type:str=Field(pattern='^(credit|debit)$'); reference_invoice:str=''; party_name:str=Field(min_length=1,max_length=200); taxable_value:float=Field(ge=0); rate:float=Field(ge=0,le=100); reason:str=''; return_period:str=Field(pattern=r'^\d{4}-(0[1-9]|1[0-2])$')

def user_dep(u=Depends(current_user)): return u

@app.middleware('http')
async def security_middleware(request:Request,call_next):
    # Enforce HTTPS when configured. Local development should use the supplied HTTPS proxy/certificate.
    forwarded_proto=request.headers.get('x-forwarded-proto','').split(',')[0].strip().lower()
    is_https=request.url.scheme=='https' or forwarded_proto=='https'
    if REQUIRE_HTTPS and not is_https:
        target=request.url.replace(scheme='https')
        return Response(status_code=307,headers={'Location':str(target)})

    rate_limit(client_key(request),limit=RATE_LIMIT_PER_MINUTE if not request.url.path.startswith('/api/auth') else max(10,RATE_LIMIT_PER_MINUTE//2))
    # Cookie-authenticated browser writes require a CSRF token. Bearer API clients are not subject to CSRF.
    if request.method in ('POST','PUT','PATCH','DELETE') and request.cookies.get('gstmitra_session') and not request.headers.get('Authorization'):
        expected=request.cookies.get('gstmitra_csrf') or ''
        supplied=request.headers.get('X-CSRF-Token','')
        if not expected or not supplied or not hmac.compare_digest(expected,supplied):
            return Response('CSRF validation failed',status_code=403)
    request_id=uuid.uuid4().hex
    try:
        response=await call_next(request)
    except HTTPException:
        raise
    response.headers['X-Request-ID']=request_id
    response.headers['X-Content-Type-Options']='nosniff'
    response.headers['X-Frame-Options']='DENY'
    response.headers['Referrer-Policy']='no-referrer'
    response.headers['Permissions-Policy']='microphone=(self)'
    if is_https or REQUIRE_HTTPS:
        response.headers['Strict-Transport-Security']='max-age=31536000; includeSubDomains'
    return response

def set_session(response:Response, token:str):
    csrf=secrets.token_urlsafe(24)
    response.set_cookie('gstmitra_session',token,max_age=TOKEN_MINUTES*60,httponly=True,secure=COOKIE_SECURE,samesite='lax',path='/')
    response.set_cookie('gstmitra_csrf',csrf,max_age=TOKEN_MINUTES*60,httponly=False,secure=COOKIE_SECURE,samesite='lax',path='/')
    return response

@app.get('/api/masters/parties')
def parties(party_type:str|None=None,user=Depends(user_dep)): return {'items':list_parties(user,party_type)}

@app.post('/api/masters/parties')
def party(x:Party,user=Depends(user_dep)):
    if x.gstin: validate_gstin(x.gstin)
    return create_party(x.model_dump(),user)

@app.get('/api/masters/items')
def items(user=Depends(user_dep)): return {'items':list_items(user)}

@app.post('/api/masters/items')
def item(x:Item,user=Depends(user_dep)): return create_item(x.model_dump(),user)

@app.get('/api/inventory/stock')
def stock(user=Depends(user_dep)): return {'items':list_stock(user)}

@app.get('/api/vouchers/notes')
def notes(period:str|None=None,user=Depends(user_dep)):
    if period: validate_period(period)
    return {'items':list_notes(user,period)}

@app.post('/api/vouchers/notes')
def note(x:Note,user=Depends(user_dep)):
    validate_period(x.return_period); guard_text(x.party_name)
    return create_note(x.model_dump(),user)

@app.get('/api/gst/gstr2b')
def gstr2b(period:str,status:str|None=None,user=Depends(user_dep)):
    validate_period(period)
    if status and status not in ('unmatched','matched','mismatch','blocked'):
        raise HTTPException(400,'Invalid reconciliation status')
    rows=list_gstr2b(user,period,status)
    total_tax=sum(float(r['total_tax']) for r in rows)
    matched=sum(1 for r in rows if r['match_status']=='matched')
    return {'period':period,'records':rows,'summary':{'total_records':len(rows),'matched':matched,'unmatched':sum(1 for r in rows if r['match_status']=='unmatched'),'mismatch':sum(1 for r in rows if r['match_status']=='mismatch'),'blocked':sum(1 for r in rows if r['match_status']=='blocked'),'total_tax':round(total_tax,2)}}

@app.post('/api/gst/gstr2b/import')
def gstr2b_import(x:GSTR2BImport,user=Depends(user_dep)):
    imported=duplicates=0
    for r in x.records:
        validate_period(r.return_period); validate_gstin(r.supplier_gstin); guard_text(r.supplier_name)
        total=Decimal(str(r.igst))+Decimal(str(r.cgst))+Decimal(str(r.sgst))
        if abs(total-Decimal(str(r.total_tax))) > Decimal('0.01'):
            raise HTTPException(422,f'Tax total mismatch for invoice {r.invoice_no}')
        canonical='|'.join([r.return_period,r.supplier_gstin,r.invoice_no,r.invoice_date or '',f'{r.taxable_value:.2f}',f'{r.igst:.2f}',f'{r.cgst:.2f}',f'{r.sgst:.2f}'])
        result=upsert_gstr2b_record({**r.model_dump(),'total_tax':float(total),'source_hash':hashlib.sha256(canonical.encode()).hexdigest()},user)
        if result['duplicate']: duplicates+=1
        else: imported+=1
    return {'imported':imported,'duplicates':duplicates,'periods':sorted({r.return_period for r in x.records})}

@app.post('/api/gst/gstr2b/reconcile')
def gstr2b_reconcile(period:str,user=Depends(user_dep)):
    validate_period(period)
    results=reconcile_gstr2b(user,period)
    rows=list_gstr2b(user,period)
    return {'period':period,'results':results,'summary':{'total':len(rows),'matched':sum(1 for r in rows if r['match_status']=='matched'),'mismatch':sum(1 for r in rows if r['match_status']=='mismatch'),'unmatched':sum(1 for r in rows if r['match_status']=='unmatched')}}

@app.get('/api/gst/itc-workspace')
def itc_workspace(period:str,user=Depends(user_dep)):
    validate_period(period)
    rows=list_gstr2b(user,period)
    buys=recent_purchases(user,10000,period)
    g2b_tax=sum(float(r['total_tax']) for r in rows)
    matched_tax=sum(float(next((b['cgst']+b['sgst']+b['igst'] for b in buys if b['id']==r['matched_purchase_id']),0)) for r in rows if r['match_status']=='matched')
    eligible=sum(float(b['eligible_itc']) for b in buys if b['itc_status'] in ('matched','eligible'))
    blocked=sum(float(b['eligible_itc']) for b in buys if b['itc_status'] in ('blocked','reversal'))
    return {'period':period,'gstr2b_tax':round(g2b_tax,2),'matched_gstr2b_tax':round(matched_tax,2),'book_eligible_itc':round(eligible,2),'blocked_or_reversed':round(blocked,2),'potential_mismatch':round(max(0,g2b_tax-matched_tax),2),'records':rows}

def _invoice_for_user(invoice_id,user):
    inv=get_invoice(user,invoice_id)
    if not inv: raise HTTPException(404,'Invoice not found')
    return inv

def _business_for_user(user):
    c=conn(); r=c.execute('SELECT id,name,gstin FROM businesses WHERE id=?',(user['business_id'],)).fetchone(); c.close()
    if not r: raise HTTPException(404,'Business not found')
    return dict(r)

@app.post('/api/integration/e-invoice/prepare')
def prepare_einvoice(x:EInvoicePrepare,user=Depends(user_dep)):
    inv=_invoice_for_user(x.invoice_id,user); biz=_business_for_user(user)
    if x.recipient_gstin: validate_gstin(x.recipient_gstin)
    if not x.place_of_supply and x.supply_type in ('B2B','B2C'): raise HTTPException(422,'Place of supply is required')
    if x.supply_type=='B2B' and not x.recipient_gstin: raise HTTPException(422,'Recipient GSTIN is required for B2B')
    if x.doc_number != (inv.get('invoice_no') or inv['id']): raise HTTPException(422,'Document number must match the invoice number')
    canonical='|'.join([biz['gstin'],x.doc_type,x.doc_number,x.doc_date or inv.get('invoice_date') or '',x.recipient_gstin,x.place_of_supply,x.supply_type,f"{float(inv['total']):.2f}"])
    ph=hashlib.sha256(canonical.encode()).hexdigest()
    c=conn(); existing=c.execute('SELECT * FROM e_invoice_preparations WHERE business_id=? AND invoice_id=?',(user['business_id'],x.invoice_id)).fetchone()
    if existing:
        c.close(); return {'status':'already_prepared',**dict(existing),'irn':None,'ack_number':None,'note':'Preparation only; no IRP submission was performed.'}
    rid=str(uuid.uuid4())
    c.execute('INSERT INTO e_invoice_preparations VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(rid,user['business_id'],x.invoice_id,x.doc_type,x.doc_number,x.doc_date or inv.get('invoice_date'),x.recipient_gstin,x.place_of_supply,x.supply_type,x.transport_mode,None,None,'draft',ph,datetime.datetime.now(datetime.timezone.utc).isoformat()))
    c.commit(); c.close(); audit(user['business_id'],user['sub'],'einvoice.prepare','invoice',x.invoice_id,ph)
    return {'id':rid,'status':'draft','invoice_id':x.invoice_id,'document_number':x.doc_number,'payload_hash':ph,'irn':None,'ack_number':None,'note':'Preparation only; connect an authorized IRP/GSP before submission.'}

@app.get('/api/integration/e-invoice')
def list_einvoice(period:str|None=None,user=Depends(user_dep)):
    c=conn(); q='SELECT e.*,i.return_period,i.customer_name,i.total FROM e_invoice_preparations e JOIN invoices i ON i.id=e.invoice_id AND i.business_id=e.business_id WHERE e.business_id=?'; p=[user['business_id']]
    if period: validate_period(period); q+=' AND i.return_period=?'; p.append(period)
    q+=' ORDER BY e.created_at DESC'; rows=[dict(r) for r in c.execute(q,p)]; c.close(); return {'items':rows}

@app.post('/api/integration/eway-bill/prepare')
def prepare_eway(x:EWayPrepare,user=Depends(user_dep)):
    inv=_invoice_for_user(x.invoice_id,user); biz=_business_for_user(user)
    if x.vehicle_number and len(x.vehicle_number)>20: raise HTTPException(422,'Vehicle number is too long')
    if x.transporter_id and len(x.transporter_id)>20: raise HTTPException(422,'Transporter ID is too long')
    canonical='|'.join([biz['gstin'],inv.get('invoice_no') or inv['id'],x.transport_mode,x.transporter_id,x.vehicle_number,x.vehicle_type,f'{x.distance_km:.2f}',f'{float(inv["total"]):.2f}'])
    ph=hashlib.sha256(canonical.encode()).hexdigest()
    c=conn(); existing=c.execute('SELECT * FROM eway_bill_preparations WHERE business_id=? AND invoice_id=?',(user['business_id'],x.invoice_id)).fetchone()
    if existing:
        c.close(); return {'status':'already_prepared',**dict(existing),'eway_bill_no':None,'note':'Preparation only; no NIC/GSP submission was performed.'}
    rid=str(uuid.uuid4())
    c.execute('INSERT INTO eway_bill_preparations VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(rid,user['business_id'],x.invoice_id,inv.get('invoice_no') or inv['id'],inv.get('invoice_date'),biz['gstin'],inv.get('customer_gstin') or '',x.transport_mode,x.transporter_id,x.vehicle_number,x.vehicle_type,x.distance_km,None,None,'draft',ph,datetime.datetime.now(datetime.timezone.utc).isoformat()))
    c.commit(); c.close(); audit(user['business_id'],user['sub'],'eway.prepare','invoice',x.invoice_id,ph)
    return {'id':rid,'status':'draft','invoice_id':x.invoice_id,'document_number':inv.get('invoice_no') or inv['id'],'payload_hash':ph,'eway_bill_no':None,'note':'Preparation only; connect an authorized E-Way Bill/GSP service before submission.'}

@app.get('/api/integration/eway-bill')
def list_eway(period:str|None=None,user=Depends(user_dep)):
    c=conn(); q='SELECT e.*,i.return_period,i.customer_name,i.total FROM eway_bill_preparations e JOIN invoices i ON i.id=e.invoice_id AND i.business_id=e.business_id WHERE e.business_id=?'; p=[user['business_id']]
    if period: validate_period(period); q+=' AND i.return_period=?'; p.append(period)
    q+=' ORDER BY e.created_at DESC'; rows=[dict(r) for r in c.execute(q,p)]; c.close(); return {'items':rows}

@app.get('/api/health')
def health(): return {'ok':True,'service':'gst-mitra','version':'4.0.0','mode':'compliance-preparation'}

@app.post('/api/auth/register')
def register(x:Register,response:Response):
    # Basic GSTIN shape validation; authoritative verification belongs to an authorized GST integration.
    gstin=validate_gstin(x.gstin)
    try: user=create_business_user(x.business_name,gstin,x.email,hash_password(x.password))
    except ValueError as e: raise HTTPException(409,str(e))
    token=create_token(user['id'],user['business_id'],user['role'])
    set_session(response,token)
    return {'access_token':token,'token_type':'bearer','user':user}

@app.post('/api/auth/login')
def login(x:Login,response:Response):
    u=get_user_by_email(x.email)
    if not u or not verify_password(x.password,u['password_hash']): raise HTTPException(401,'Invalid email or password')
    token=create_token(u['id'],u['business_id'],u['role'])
    set_session(response,token)
    return {'access_token':token,'token_type':'bearer','user':{'id':u['id'],'business_id':u['business_id'],'role':u['role'],'email':u['email']}}

@app.post('/api/auth/logout')
def logout(response:Response):
    response.delete_cookie('gstmitra_session',path='/')
    response.delete_cookie('gstmitra_csrf',path='/')
    return {'ok':True}

@app.post('/api/gst/calculate')
def calc(x:Calc, user=Depends(user_dep)): return calculate(x.subtotal,x.rate,x.intra_state)

@app.post('/api/agent')
async def agent(x:AgentReq,user=Depends(user_dep)):
    guard_text(x.text)
    intent=classify_intent(x.text)
    # The model is advisory only: high-impact actions never execute from natural language.
    if intent['requires_confirmation']:
        action_id=secrets.token_urlsafe(24)
        audit(user['business_id'],user['sub'],'ai.high_impact_blocked','ai_action',action_id,json.dumps({'text':x.text[:500],'intent':intent['intent']}))
        return {'reply':'Yeh high-impact action hai. Main chat se ise execute nahi karunga. GST Mitra ke relevant tool/screen par jaakar details verify karke explicit confirmation dein.', 'intent':intent, 'action_id':action_id}
    audit(user['business_id'],user['sub'],'ai.intent','ai_intent',intent['intent'],json.dumps({'text':x.text[:500]}))
    return {'reply':await reply(x.text),'intent':intent}

@app.post('/api/agent/confirm')
def agent_confirm(x:AgentConfirm,user=Depends(user_dep)):
    # Confirmation alone is intentionally not an execution primitive. Actual mutations must go through typed endpoints.
    if not x.confirmed:
        audit(user['business_id'],user['sub'],'ai.confirm_cancel','ai_action',x.action_id,'{}')
        return {'status':'cancelled'}
    audit(user['business_id'],user['sub'],'ai.confirmation_received','ai_action',x.action_id,json.dumps({'execution':'typed_tool_required'}))
    return {'status':'confirmed','note':'Confirmation recorded. Execute the requested operation only through its authorized typed GST Mitra tool.'}


@app.post('/api/invoices')
def invoice(x:Invoice,user=Depends(user_dep)):
    if get_period_status(user,x.return_period)['status']=='locked': raise HTTPException(409,'Accounting period is locked')
    validate_period(x.return_period); guard_text(x.customer_name)
    customer_gstin=validate_gstin(x.customer_gstin) if x.customer_gstin else ''
    hsn=x.hsn_sac; description=x.description; rate=x.rate; subtotal=x.subtotal
    if x.item_id:
        c=conn(); itemrow=c.execute('SELECT * FROM items WHERE id=? AND business_id=?',(x.item_id,user['business_id'])).fetchone(); c.close()
        if not itemrow: raise HTTPException(404,'Item not found')
        if itemrow['stock_qty'] < x.quantity: raise HTTPException(409,'Insufficient stock')
        hsn=itemrow['hsn_sac'] or hsn; description=itemrow['name']; rate=itemrow['gst_rate']; subtotal=round(itemrow['sale_price']*x.quantity,2)
    totals=calculate(subtotal,rate,x.intra_state)
    invoice_id=f'GM-{datetime.datetime.now().strftime("%Y%m%d")}-{uuid.uuid4().hex[:6].upper()}'
    invoice_no=next_invoice_no(user['business_id'],x.return_period)
    data={'invoice_id':invoice_id,'invoice_no':invoice_no,'customer_name':x.customer_name,'customer_gstin':customer_gstin,'description':description,'hsn_sac':hsn,'invoice_date':x.invoice_date,'rate':rate,'intra_state':x.intra_state,'return_period':x.return_period,'quantity':x.quantity,**totals}
    try:
        save_invoice(data,user)
        if x.item_id: record_stock_sale(x.item_id,invoice_id,x.quantity,user)
    except ValueError as e: raise HTTPException(409,str(e))
    return data

@app.get('/api/invoices')
def invoices(period:str|None=None,limit:int=20,user=Depends(user_dep)): return {'items':recent_invoices(user,max(1,min(limit,100)),period)}

@app.get('/api/invoices/{invoice_id}/html')
def invoice_html(invoice_id:str,user=Depends(user_dep)):
    item=next((x for x in recent_invoices(user,10000) if x['id']==invoice_id),None)
    if not item: return Response('Invoice not found',status_code=404)
    e={k:html.escape(str(v)) for k,v in item.items()}
    html_doc=f'''<!doctype html><html><head><meta charset="utf-8"><title>{e['id']}</title><meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline';"><style>body{{font-family:Arial;max-width:800px;margin:40px auto}}table{{width:100%;border-collapse:collapse}}td,th{{padding:10px;border:1px solid #ddd}}h1{{margin-bottom:4px}}</style></head><body><h1>GST Mitra Tax Invoice</h1><p><b>Invoice:</b> {e['id']}<br><b>Date:</b> {e['created_at'][:10]}<br><b>Customer:</b> {e['customer_name']}<br><b>GSTIN:</b> {e['customer_gstin'] or '—'}</p><table><tr><th>Description</th><th>Taxable</th><th>GST %</th><th>Tax</th><th>Total</th></tr><tr><td>Taxable supply</td><td>₹{item['subtotal']:.2f}</td><td>{item['rate']:.2f}%</td><td>₹{item['total']-item['subtotal']:.2f}</td><td>₹{item['total']:.2f}</td></tr></table><p>CGST: ₹{item['cgst']:.2f} &nbsp; SGST: ₹{item['sgst']:.2f} &nbsp; IGST: ₹{item['igst']:.2f}</p><h2>Total: ₹{item['total']:.2f}</h2><p>Generated by GST Mitra. Verify statutory particulars before issue.</p></body></html>'''
    return Response(html_doc,media_type='text/html')

@app.post('/api/invoices/validate')
def validate_invoice(x:MultiInvoice,user=Depends(user_dep)):
    validate_period(x.return_period); guard_text(x.customer_name)
    if x.customer_gstin: validate_gstin(x.customer_gstin)
    issues=[]; totals={'taxable':Decimal('0.00'),'cgst':Decimal('0.00'),'sgst':Decimal('0.00'),'igst':Decimal('0.00'),'total':Decimal('0.00')}
    for line in x.lines:
        if line.item_id:
            c=conn(); r=c.execute('SELECT gst_rate,sale_price,stock_qty,hsn_sac FROM items WHERE id=? AND business_id=?',(line.item_id,user['business_id'])).fetchone(); c.close()
            if not r: issues.append(f'Item {line.item_id} not found'); continue
            if r['stock_qty'] < line.quantity: issues.append(f'Insufficient stock for item {line.item_id}')
            if abs(float(r['gst_rate'])-line.rate)>0.001: issues.append(f'GST rate differs from item master for {line.item_id}')
        t=calculate(line.quantity*line.unit_price,line.rate,x.intra_state)
        for k in ('taxable_value','cgst','sgst','igst','total'): totals[{'taxable_value':'taxable','cgst':'cgst','sgst':'sgst','igst':'igst','total':'total'}[k]] += Decimal(str(t[k]))
    return {'valid':not issues,'issues':issues,'totals':{k:float(v.quantize(Decimal('0.01'))) for k,v in totals.items()}}

@app.post('/api/invoices/multi')
def create_multi_invoice(x:MultiInvoice,user=Depends(user_dep)):
    validate_period(x.return_period); guard_text(x.customer_name)
    if x.customer_gstin: validate_gstin(x.customer_gstin)
    inv_id=f'GM-{datetime.datetime.now().strftime("%Y%m%d")}-{uuid.uuid4().hex[:6].upper()}'
    inv_no=next_invoice_no(user['business_id'],x.return_period)
    line_rows=[]; total_taxable=Decimal('0.00'); total_cgst=Decimal('0.00'); total_sgst=Decimal('0.00'); total_igst=Decimal('0.00'); total=Decimal('0.00')
    try:
        for line in x.lines:
            desc=line.description; hsn=line.hsn_sac; rate=line.rate; unit=line.unit
            if line.item_id:
                c=conn(); r=c.execute('SELECT * FROM items WHERE id=? AND business_id=?',(line.item_id,user['business_id'])).fetchone(); c.close()
                if not r: raise ValueError('Item not found')
                if r['stock_qty'] < line.quantity: raise ValueError(f'Insufficient stock for {r["name"]}')
                desc=r['name']; hsn=r['hsn_sac'] or hsn; rate=float(r['gst_rate']); unit=r['unit']; line_price=float(r['sale_price'])
            else: line_price=line.unit_price
            t=calculate(line.quantity*line_price,rate,x.intra_state)
            total_taxable+=Decimal(str(t['taxable_value'])); total_cgst+=Decimal(str(t['cgst'])); total_sgst+=Decimal(str(t['sgst'])); total_igst+=Decimal(str(t['igst'])); total+=Decimal(str(t['total']))
            line_rows.append((line,desc,hsn,rate,unit,line_price,t))
        data={'invoice_id':inv_id,'invoice_no':inv_no,'customer_name':x.customer_name,'customer_gstin':x.customer_gstin,'description':line_rows[0][1],'hsn_sac':line_rows[0][2],'invoice_date':x.invoice_date,'rate':line_rows[0][3],'intra_state':x.intra_state,'return_period':x.return_period,'quantity':sum(l[0].quantity for l in line_rows),'taxable_value':float(total_taxable),'cgst':float(total_cgst),'sgst':float(total_sgst),'igst':float(total_igst),'total':float(total)}
        save_invoice(data,user)
        for line,desc,hsn,rate,unit,price,t in line_rows:
            add_invoice_line({'invoice_id':inv_id,'item_id':line.item_id,'description':desc,'hsn_sac':hsn,'quantity':line.quantity,'unit':unit,'unit_price':price,'taxable_value':t['taxable_value'],'rate':rate,'cgst':t['cgst'],'sgst':t['sgst'],'igst':t['igst'],'total':t['total']},user)
            if line.item_id: record_stock_sale(line.item_id,inv_id,line.quantity,user)
        return get_invoice(user,inv_id)
    except ValueError as e: raise HTTPException(409,str(e))

@app.get('/api/invoices/{invoice_id}/pdf')
def invoice_pdf(invoice_id:str,user=Depends(user_dep)):
    inv=get_invoice(user,invoice_id)
    if not inv: raise HTTPException(404,'Invoice not found')
    buf=BytesIO(); c=canvas.Canvas(buf,pagesize=A4); w,h=A4
    y=h-50; c.setFont('Helvetica-Bold',18); c.drawString(50,y,'GST MITRA TAX INVOICE'); y-=24
    c.setFont('Helvetica',10); c.drawString(50,y,'Sharma Traders Pvt. Ltd.'); y-=16; c.drawString(50,y,f'Invoice No: {inv.get("invoice_no") or inv["id"]}'); c.drawRightString(w-50,y,f'Date: {inv.get("invoice_date") or inv["created_at"][:10]}'); y-=16
    c.drawString(50,y,f'Customer: {inv["customer_name"]}'); y-=14; c.drawString(50,y,f'GSTIN: {inv.get("customer_gstin") or "—"}'); y-=24
    c.setFont('Helvetica-Bold',9); c.drawString(50,y,'Description'); c.drawString(280,y,'Qty'); c.drawString(330,y,'Rate'); c.drawString(390,y,'GST'); c.drawString(460,y,'Total'); y-=14; c.setFont('Helvetica',9)
    lines=inv.get('lines') or [{'description':inv.get('description','Taxable supply'),'quantity':inv.get('quantity',1),'unit_price':inv['subtotal']/max(inv.get('quantity',1),1),'rate':inv['rate'],'total':inv['total']}]
    for line in lines:
        c.drawString(50,y,str(line.get('description',''))[:38]); c.drawRightString(305,y,f'{float(line.get("quantity",1)):.2f}'); c.drawRightString(365,y,f'₹{float(line.get("unit_price",0)):.2f}'); c.drawRightString(435,y,f'{float(line.get("rate",0)):.2f}%'); c.drawRightString(w-50,y,f'₹{float(line.get("total",0)):.2f}'); y-=16
        if y<100: c.showPage(); y=h-50
    y-=8; c.line(350,y,w-50,y); y-=18; c.drawRightString(w-50,y,f'Taxable: ₹{float(inv["subtotal"]):,.2f}'); y-=14; c.drawRightString(w-50,y,f'CGST: ₹{float(inv["cgst"]):,.2f}'); y-=14; c.drawRightString(w-50,y,f'SGST: ₹{float(inv["sgst"]):,.2f}'); y-=14; c.drawRightString(w-50,y,f'IGST: ₹{float(inv["igst"]):,.2f}'); y-=18; c.setFont('Helvetica-Bold',12); c.drawRightString(w-50,y,f'Grand Total: ₹{float(inv["total"]):,.2f}'); y-=30; c.setFont('Helvetica',8); c.drawString(50,y,'Generated by GST Mitra. Verify statutory particulars before issue/file submission.')
    c.save(); buf.seek(0); return StreamingResponse(buf,media_type='application/pdf',headers={'Content-Disposition':f'inline; filename="{inv.get("invoice_no") or invoice_id}.pdf"'})

@app.post('/api/inventory/adjust')
def inventory_adjust(x:StockAdjustment,user=Depends(user_dep)):
    try: return adjust_stock(x.item_id,x.quantity,x.reason,user)
    except ValueError as e: raise HTTPException(409,str(e))

@app.get('/api/inventory/movements')
def inventory_movements(item_id:str|None=None,limit:int=100,user=Depends(user_dep)): return {'items':stock_movements(user,item_id,limit)}

@app.post('/api/purchases')
def purchase(x:PurchaseV2,user=Depends(user_dep)):
    if get_period_status(user,x.return_period)['status']=='locked': raise HTTPException(409,'Accounting period is locked')
    validate_period(x.return_period); guard_text(x.vendor_name)
    vendor_gstin=validate_gstin(x.vendor_gstin) if x.vendor_gstin else ''
    taxable=Decimal(str(x.taxable_value)) if x.taxable_value is not None else Decimal(str(x.unit_price))*Decimal(str(x.quantity))
    t=calculate(taxable,x.rate,x.intra_state); tax=Decimal(str(t['cgst']))+Decimal(str(t['sgst']))+Decimal(str(t['igst']))
    eligible=min(Decimal(str(x.eligible_itc if x.eligible_itc is not None else 0)),tax)
    data={'purchase_id':f'PUR-{datetime.datetime.now().strftime("%Y%m%d")}-{uuid.uuid4().hex[:6].upper()}','vendor_name':x.vendor_name,'vendor_gstin':vendor_gstin,'eligible_itc':float(eligible.quantize(Decimal('0.01'))),'itc_status':x.itc_status,'return_period':x.return_period,'taxable_value':t['taxable_value'],'rate':t['rate'],'intra_state':x.intra_state,'cgst':t['cgst'],'sgst':t['sgst'],'igst':t['igst'],'total':t['total']}
    try:
        save_purchase(data,user)
        save_purchase_line({'purchase_id':data['purchase_id'],'item_id':x.item_id,'description':x.description,'hsn_sac':x.hsn_sac,'quantity':x.quantity,'unit':'NOS','unit_price':x.unit_price,'taxable_value':t['taxable_value'],'rate':x.rate,'eligible_itc':float(eligible)},user)
        if x.item_id: record_stock_purchase(x.item_id,data['purchase_id'],x.quantity,user)
    except ValueError as e: raise HTTPException(409,str(e))
    return data

@app.get('/api/purchases')
def purchases(period:str|None=None,limit:int=50,user=Depends(user_dep)): return {'items':recent_purchases(user,max(1,min(limit,200)),period)}

@app.get('/api/gst/summary')
def summary(period:str|None=None,user=Depends(user_dep)):
    if period: validate_period(period)
    sales=recent_invoices(user,10000,period); buys=recent_purchases(user,10000,period)
    output_tax=sum(x['total']-x['subtotal'] for x in sales); itc=sum(x['eligible_itc'] for x in buys if x['itc_status'] in ('matched','eligible'))
    return {'period':period,'invoice_count':len(sales),'purchase_count':len(buys),'taxable_value':round(sum(x['subtotal'] for x in sales),2),'gst_collected':round(output_tax,2),'eligible_itc':round(itc,2),'estimated_net_tax':round(max(0,output_tax-itc),2),'total_sales':round(sum(x['total'] for x in sales),2)}

@app.get('/api/returns/gstr1')
def gstr1(period:str,user=Depends(user_dep)):
    validate_period(period)
    sales=recent_invoices(user,10000,period)
    return {'status':'draft','period':period,'invoice_count':len(sales),'taxable_value':round(sum(x['subtotal'] for x in sales),2),'cgst':round(sum(x['cgst'] for x in sales),2),'sgst':round(sum(x['sgst'] for x in sales),2),'igst':round(sum(x['igst'] for x in sales),2),'rows':sales,'warning':'Draft only. Validate classification, GSTIN, place of supply, notes/amendments and statutory rules before filing.'}

@app.get('/api/returns/gstr3b')
def gstr3b(period:str,user=Depends(user_dep)):
    validate_period(period)
    s=summary(period,user); return {'status':'draft','period':period,'outward_taxable_value':s['taxable_value'],'outward_tax':s['gst_collected'],'eligible_itc':s['eligible_itc'],'estimated_net_tax':s['estimated_net_tax'],'warning':'Draft calculation only; verify eligibility, reversals, exemptions and statutory rules before filing.'}


@app.get('/api/accounting/period')
def accounting_period(period:str,user=Depends(user_dep)):
    validate_period(period); return get_period_status(user,period)

@app.post('/api/accounting/period/lock')
def lock_accounting_period(period:str,user=Depends(user_dep)):
    validate_period(period)
    if user.get('role')!='owner': raise HTTPException(403,'Only the business owner can lock periods')
    return set_period_status(user,period,'locked')

@app.post('/api/accounting/period/unlock')
def unlock_accounting_period(period:str,user=Depends(user_dep)):
    validate_period(period)
    if user.get('role')!='owner': raise HTTPException(403,'Only the business owner can unlock periods')
    return set_period_status(user,period,'open')

@app.get('/api/reports/summary')
def report_summary(period:str,user=Depends(user_dep)):
    validate_period(period); sales=recent_invoices(user,10000,period); purchases=recent_purchases(user,10000,period)
    taxable=sum(float(x.get('subtotal',0)) for x in sales); sales_total=sum(float(x.get('total',0)) for x in sales); purchase_taxable=sum(float(x.get('taxable_value',0)) for x in purchases)
    output_tax=sum(float(x.get('cgst',0))+float(x.get('sgst',0))+float(x.get('igst',0)) for x in sales); itc=sum(float(x.get('eligible_itc',0)) for x in purchases if x.get('itc_status') in ('matched','eligible'))
    return {'period':period,'sales':{'invoice_count':len(sales),'taxable':round(taxable,2),'gross':round(sales_total,2),'output_tax':round(output_tax,2)},'purchases':{'count':len(purchases),'taxable':round(purchase_taxable,2),'eligible_itc':round(itc,2)},'profitability':{'gross_margin_before_expenses':round(taxable-purchase_taxable,2)},'gst':{'net_tax_estimate':round(max(0,output_tax-itc),2)},'status':get_period_status(user,period)['status']}

@app.get('/api/reports/ledger')
def report_ledger(period:str,limit:int=200,user=Depends(user_dep)):
    validate_period(period); limit=max(1,min(limit,1000)); sales=recent_invoices(user,limit,period); purchases=recent_purchases(user,limit,period); rows=[]
    rows += [{'date':x.get('invoice_date') or x.get('created_at'),'type':'SALE','reference':x.get('invoice_no') or x.get('id'),'party':x.get('customer_name'),'debit':0,'credit':round(float(x.get('total',0)),2)} for x in sales]
    rows += [{'date':x.get('created_at'),'type':'PURCHASE','reference':x.get('purchase_id') or x.get('id'),'party':x.get('vendor_name'),'debit':round(float(x.get('taxable_value',0))+float(x.get('eligible_itc',0)),2),'credit':0} for x in purchases]
    rows.sort(key=lambda r:r['date'] or '',reverse=True); return {'period':period,'rows':rows[:limit]}

@app.get('/api/me')
def me(user=Depends(user_dep)):
    c=conn(); r=c.execute('SELECT id,name,gstin,created_at FROM businesses WHERE id=?',(user['business_id'],)).fetchone(); c.close()
    if not r: raise HTTPException(404,'Business not found')
    return {'user':{'id':user['sub'],'business_id':user['business_id'],'role':user['role']},'business':dict(r)}

@app.get('/api/audit')
def audit_events(limit:int=50,user=Depends(user_dep)):
    limit=max(1,min(limit,200)); c=conn(); rows=[dict(r) for r in c.execute('SELECT id,action,object_type,object_id,metadata,created_at FROM audit_logs WHERE business_id=? ORDER BY created_at DESC LIMIT ?',(user['business_id'],limit))]; c.close(); return {'items':rows}
