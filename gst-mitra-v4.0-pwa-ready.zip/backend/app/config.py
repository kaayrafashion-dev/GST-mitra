import os
from dotenv import load_dotenv
load_dotenv()
SECRET_KEY=os.getenv('SECRET_KEY','')
APP_ENV=os.getenv('APP_ENV','development').lower()
REQUIRE_HTTPS=os.getenv('REQUIRE_HTTPS','true').lower() in ('1','true','yes','on')
COOKIE_SECURE=os.getenv('COOKIE_SECURE','true').lower() in ('1','true','yes','on')
CORS_ORIGINS=[x.strip() for x in os.getenv('CORS_ORIGINS','https://localhost:5173').split(',') if x.strip()]
LLM_BASE_URL=os.getenv('LLM_BASE_URL','').rstrip('/')
LLM_API_KEY=os.getenv('LLM_API_KEY','')
LLM_MODEL=os.getenv('LLM_MODEL','')
TOKEN_MINUTES=int(os.getenv('TOKEN_MINUTES','120'))
RATE_LIMIT_PER_MINUTE=int(os.getenv('RATE_LIMIT_PER_MINUTE','60'))
