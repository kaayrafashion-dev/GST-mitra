from PIL import Image, ImageDraw, ImageFont

def make_icon(size, path, maskable=False):
    img = Image.new("RGB", (size, size), "#1027b8")
    draw = ImageDraw.Draw(img)
    top = (16, 39, 184)
    bottom = (23, 56, 223)
    for y in range(size):
        t = y / size
        r = int(top[0] + (bottom[0]-top[0])*t)
        g = int(top[1] + (bottom[1]-top[1])*t)
        b = int(top[2] + (bottom[2]-top[2])*t)
        draw.line([(0,y),(size,y)], fill=(r,g,b))

    try:
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", int(size*0.5))
    except Exception:
        font = ImageFont.load_default()
    text = "G"
    bbox = draw.textbbox((0,0), text, font=font)
    tw, th = bbox[2]-bbox[0], bbox[3]-bbox[1]
    draw.text(((size-tw)/2 - bbox[0], (size-th)/2 - bbox[1] - size*0.02), text, fill="white", font=font)
    img.save(path, "PNG")

make_icon(192, "/home/claude/gst-mitra/gst-mitra-v4.0/frontend/public/icon-192.png")
make_icon(512, "/home/claude/gst-mitra/gst-mitra-v4.0/frontend/public/icon-512.png")
make_icon(512, "/home/claude/gst-mitra/gst-mitra-v4.0/frontend/public/icon-maskable-512.png", maskable=True)
print("done")
