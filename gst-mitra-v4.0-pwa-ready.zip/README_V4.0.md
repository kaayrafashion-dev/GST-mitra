# GST Mitra V4.0

Modern GST/accounting workspace with professional billing, inventory, GST preparation, ITC reconciliation, e-invoice/e-way preparation, advanced reports, print utilities, and a guarded Mitra voice/AI assistant.

## Run backend
```bash
cd backend
pip install -r requirements.txt
PYTHONPATH=. uvicorn app.main:app --host 127.0.0.1 --port 8000
```

For production use HTTPS through the supplied Caddy configuration and run `python scripts/production_preflight.py` with production environment variables.
