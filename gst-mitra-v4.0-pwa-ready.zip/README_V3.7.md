# GST Mitra V3.7 — Mitra Voice AI Production Hardening

Adds a secure voice/AI intent layer. Natural-language requests are classified, read-only intents are advisory, and high-impact actions are blocked from direct execution. Explicit confirmation is recorded but never acts as a mutation primitive; typed, authorized GST tools remain the only execution path. AI actions are audit logged and existing HTTPS/session/CSRF/tenant controls remain.

## Voice flow
User voice -> browser speech recognition -> `/api/agent` -> intent guard -> advisory response or high-impact block -> typed authorized tool.
