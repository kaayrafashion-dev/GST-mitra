# GST Mitra V3.6 — Advanced Reports + Accounting Controls

Adds period controls and reporting APIs on top of V3.5.

## Added
- Period status: open/locked
- Owner-only period lock/unlock
- Locked periods reject new sales/purchases/invoices
- Management report summary: sales, purchases, output tax, eligible ITC, estimated net tax, gross margin before expenses
- Period ledger report
- Tenant-isolated reporting
- Audit logging for period lock/unlock

## Important
This is an accounting-control foundation, not a full double-entry general ledger. Statutory filing remains draft/preparation-only until authorized integrations and validation are configured.

## Verification
- Backend pytest: 9/9 passed
- Python compile: passed
