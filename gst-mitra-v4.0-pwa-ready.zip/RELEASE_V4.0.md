# GST Mitra V4.0 Release Candidate

V4.0 consolidates the V3.0–V3.7 feature line and the V3.8 final audit gate.

## Included
- Professional billing and inventory
- GSTR-1/GSTR-3B preparation
- GSTR-2B/ITC reconciliation workspace
- E-Invoice/E-Way Bill preparation workflows
- Advanced reports and accounting period controls
- Mitra Voice AI safety hardening
- HTTPS-first authentication/session architecture
- Print Utilities
- BUSY-inspired accounting navigation with modern responsive UI
- 27-team release audit

## Release status
**STAGING RELEASE CANDIDATE — CONDITIONAL PRODUCTION GO**

Production requires: live authorized GST/GSP/IRP/NIC integrations as applicable, real HTTPS certificates and domain, centralized Redis rate limiting, managed database/backups, browser E2E/accessibility testing, load testing, observability/alerts, and a controlled secrets/rollback process.
