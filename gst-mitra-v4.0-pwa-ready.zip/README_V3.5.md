# GST Mitra V3.5 — E-Invoice + E-Way Bill Workflow

Milestone 2/6 of the GST Mitra roadmap.

## Added
- E-Invoice preparation endpoint with B2B GSTIN and place-of-supply validation.
- E-Way Bill preparation endpoint with transport/vehicle/distance validation.
- Tenant-isolated preparation records with payload hashes and audit events.
- Duplicate preparation protection per business + invoice.
- Frontend E-Invoice / E-Way Bill workspace under **GST → E-Invoice / E-Way Bill**.
- Explicit preparation-only boundary: no fake IRN, acknowledgement number, or E-Way Bill number is generated.

## Production boundary
Actual IRP/GSP/NIC submission requires an authorized integration and credentials. This milestone prepares and validates payload data but does not claim statutory filing or issuance.

## Tests
Backend: `9 passed`.
Frontend production build requires Node dependencies installed in a normal build environment.
