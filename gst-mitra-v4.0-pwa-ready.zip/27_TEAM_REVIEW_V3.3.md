
## V3.3 Red-Team hardening
- Browser JWT localStorage: fixed; HttpOnly Secure session cookie introduced.
- CSRF: fixed for cookie-authenticated state-changing requests.
- Weak production secret fallback: fixed; staging/production fail closed.
- HTTPS: production enforcement + HSTS added; local HTTPS reverse-proxy guidance included.
- Frontend API requests: credentials + CSRF token; no localStorage token.
- Logout: session/CSRF cookies cleared.
- Remaining production gate: run full frontend build/E2E in a networked Node environment and deploy behind a trusted TLS proxy.
